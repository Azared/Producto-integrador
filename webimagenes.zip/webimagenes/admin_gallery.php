
<?php
session_start();

// Verificar si el usuario ha iniciado sesión como administrador
if (!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] != true) {
  header("Location: login.php");
  exit();
}

// Obtener la lista de usuarios
$users = scandir("galleries");

// Mostrar las galerías de los usuarios
echo "<h1>Galerías de usuarios</h1>";
foreach ($users as $user) {
  if ($user != "." && $user != "..") {
    echo "<h2>Galería de imágenes de $user</h2>";
    echo "<h3>Subir imagen:</h3>";
    echo "<form action='upload.php' method='POST' enctype='multipart/form-data'>";
    echo "<input type='hidden' name='username' value='$user'>";
    echo "<input type='file' name='image'>";
    echo "<button type='submit'>Subir</button>";
    echo "</form>";

    // Mostrar las imágenes del usuario
    $directory = "galleries/$user/";
    if ($handle = opendir($directory)) {
      while (false !== ($entry = readdir($handle))) {
        if ($entry != "." && $entry != "..") {
          echo "<img src='$directory/$entry'>";
          echo "<button onclick='deleteImage(\"$entry\", \"$user\")'>Eliminar</button>";
        }
      }
      closedir($handle);
    }
  }
}

// Función para eliminar una imagen
echo "<script>";
echo "function deleteImage(image, username) {";
echo "  if (confirm('Desea eliminar esta imagen?')) {";
echo "    window.location = 'delete.php?image=' + image + '&username=' + username;";
echo "  }";
echo "}";
echo "</script>";
?>

