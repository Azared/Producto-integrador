
<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

// Verificar si el usuario es el administrador
$isAdmin = false;
if (isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] == true) {
  $isAdmin = true;
}

// Obtener el nombre de usuario actual
$username = $_SESSION['username'];

// Mostrar la galería del usuario
echo "<h1>Galería de imágenes de $username</h1>";
echo "<h3>Subir imagen:</h3>";
echo "<form action='upload.php' method='POST' enctype='multipart/form-data'>";
echo "<input type='file' name='image'>";
echo "<button type='submit'>Subir</button>";
echo "</form>";

// Mostrar las imágenes del usuario
$directory = "galleries/$username/";
if ($handle = opendir($directory)) {
  while (false !== ($entry = readdir($handle))) {
    if ($entry != "." && $entry != "..") {
      echo "<img src='$directory/$entry'>";
      if ($isAdmin) {
        echo "<button onclick='deleteImage(\"$entry\")'>Eliminar</button>";
      }
    }
  }
  closedir($handle);
}

// Función para eliminar una imagen
echo "<script>";
echo "function deleteImage(image) {";
echo "  if (confirm('Desea eliminar esta imagen?')) {";
echo "    window.location = 'delete.php?image=' + image;";
echo "  }";
echo "}";
echo "</script>";
?>

