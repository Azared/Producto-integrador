
<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

// Obtener el nombre de usuario actual
$username = $_SESSION['username'];

// Verificar si el usuario es el administrador
$isAdmin = false;
if (isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] == true) {
  $isAdmin = true;
}

// Obtener el nombre del archivo a eliminar
$image = $_GET['image'];

// Verificar si se ha especificado un nombre de usuario para eliminar una imagen de su galería
if ($isAdmin && isset($_GET['username'])) {
  $username = $_GET['username'];
}

// Verificar si el archivo pertenece al usuario (o si el usuario es el administrador)
$directory = "galleries/$username";
$imagePath = $directory . "/" . $image;

if ($isAdmin || (is_dir($directory) && file_exists($imagePath))) {
  // Eliminar la imagen
  unlink($imagePath);

  // Redirigir a la galería correspondiente
  if ($isAdmin) {
    header("Location: admin_gallery.php");
  } else {
    header("Location: user_gallery.php");
  }
} else {
  echo "No tiene permiso para eliminar esta imagen.";
}
?>

