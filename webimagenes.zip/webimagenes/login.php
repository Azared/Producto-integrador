
<?php
session_start();

// Verificar si el usuario y la contraseña son correctos
$adminUser = "admin";
$adminPass = "admin123";
$user = $_POST['username'];
$pass = $_POST['password'];

if ($user == $adminUser && $pass == $adminPass) {
  $_SESSION['isAdmin'] = true;
  $_SESSION['username'] = $user;
  header("Location: admin_gallery.php");
  exit();
} else {
  $_SESSION['isAdmin'] = false;
  $_SESSION['username'] = $user;
  header("Location: user_gallery.php");
  exit();
}
//http://localhost/plb/otras%20avtvidades/webimagenes/index.html
?>

