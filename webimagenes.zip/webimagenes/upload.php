
<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

// Obtener el nombre de usuario actual
$username = $_SESSION['username'];

// Verificar si se ha especificado un nombre de usuario para subir una imagen a su galería
if (isset($_POST['username'])) {
  $username = $_POST['username'];
}

// Obtener la información del archivo
$file = $_FILES['image'];
$filename = $file['name'];
$tempPath = $file['tmp_name'];

// Verificar si ya existe una carpeta para la galería del usuario
$directory = "galleries/$username";
if (!is_dir($directory)) {
  mkdir($directory);
}

// Mover la imagen a la galería del usuario
$targetPath = $directory . "/" . $filename;
move_uploaded_file($tempPath, $targetPath);

// Redirigir a la galería correspondiente
if (isset($_POST['username'])) {
  header("Location: user_gallery.php");
} else {
  header("Location: admin_gallery.php");
}
?>

